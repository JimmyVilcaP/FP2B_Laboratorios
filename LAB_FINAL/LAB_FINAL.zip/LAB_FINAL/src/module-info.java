/**
 * 
 */
/**
 * 
 */
module LAB_FINAL {
	requires java.desktop;
}