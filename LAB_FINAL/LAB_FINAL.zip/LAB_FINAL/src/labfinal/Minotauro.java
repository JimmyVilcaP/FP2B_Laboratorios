package labfinal;

public class Minotauro extends Monstruo {
    public Minotauro(int x, int y) {
        super(120, 25, x); 
    }

}