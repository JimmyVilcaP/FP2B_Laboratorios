package labfinal;

public class Goblin extends Monstruo {
    public Goblin(int salud, int ataque) {
        super(salud, ataque, 7);  // Goblins tienen defensa media
    }
}
