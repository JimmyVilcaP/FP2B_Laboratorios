package labfinal;

public class JefeFinal extends Monstruo {
    public JefeFinal(int salud, int ataque) {
        super(salud, ataque, 20);  // Jefe final tiene mucha defensa
    }
}
