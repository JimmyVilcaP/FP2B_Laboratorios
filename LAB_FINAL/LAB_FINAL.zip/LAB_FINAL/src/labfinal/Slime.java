package labfinal;

public class Slime extends Monstruo {
    public Slime(int salud, int ataque) {
        super(salud, ataque, 5);  // Slimes tienen baja defensa
    }
}
