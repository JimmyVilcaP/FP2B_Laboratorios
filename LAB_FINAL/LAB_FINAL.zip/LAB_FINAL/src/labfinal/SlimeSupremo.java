package labfinal;

public class SlimeSupremo extends Slime {
    public SlimeSupremo(int salud, int ataque) {
        super(salud, ataque);
        this.defensa = 15;  // Slime Rey tiene mucha más defensa
    }
}
