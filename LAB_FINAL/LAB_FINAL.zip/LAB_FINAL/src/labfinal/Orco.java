package labfinal;

public class Orco extends Monstruo {
    public Orco(int x, int y) {
        super(100, 15, x);
    }

}
